package school.faang.user_service.entity.payment;

public enum Currency {
    USD, EUR
}
