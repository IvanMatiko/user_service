package school.faang.user_service.entity.payment;

public enum PaymentStatus {
    SUCCESS, FAILED
}
