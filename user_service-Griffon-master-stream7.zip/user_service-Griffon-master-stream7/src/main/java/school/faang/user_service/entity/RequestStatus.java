package school.faang.user_service.entity;

public enum RequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}