package school.faang.user_service.exception.participation;

public class ParticipationException  extends RuntimeException {
    public ParticipationException(String message) {
        super(message);
    }
}
