package school.faang.user_service.entity.goal;

public enum GoalStatus {
    ACTIVE,
    COMPLETED
}