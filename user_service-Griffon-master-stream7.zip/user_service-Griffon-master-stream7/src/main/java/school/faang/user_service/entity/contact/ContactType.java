package school.faang.user_service.entity.contact;

public enum ContactType {
    GITHUB, TELEGRAM, VK, FACEBOOK, INSTAGRAM, WHATSAPP, CUSTOM
}