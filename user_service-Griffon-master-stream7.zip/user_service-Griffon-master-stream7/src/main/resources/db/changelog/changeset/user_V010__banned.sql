ALTER TABLE users
    ADD COLUMN banned boolean DEFAULT false NOT NULL;